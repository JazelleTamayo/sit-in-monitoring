<?php
session_start();

// Auth guard - redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?error=" . urlencode("Please login first"));
    exit();
}

// Redirect admin to admin dashboard
if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true) {
    header("Location: admin_dashboard.php");
    exit();
}

$pageTitle = "Reservation - CCS Sit-in System";
$extraCSS = "dashboard";
$basePath = "../";

// Include database connection
require_once __DIR__ . '/../config/database.php';

// Get current user info from database to ensure latest data
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Get remaining sessions (you can adjust this logic based on your system)
// For now, we'll use a default value or get from session
$remaining_sessions = isset($_SESSION['sessions_remaining']) ? $_SESSION['sessions_remaining'] : 30;

// Handle form submission
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reserve'])) {
    // Get form data
    $purpose = trim($_POST['purpose'] ?? '');
    $lab = trim($_POST['lab'] ?? '');
    $time_in = trim($_POST['time_in'] ?? '');
    $date = trim($_POST['date'] ?? '');
    
    // Validation
    $errors = [];
    
    if (empty($purpose)) $errors[] = "Purpose is required";
    if (empty($lab)) $errors[] = "Laboratory is required";
    if (empty($time_in)) $errors[] = "Time in is required";
    if (empty($date)) $errors[] = "Date is required";
    
    // Check if date is valid format (dd/mm/yyyy)
    if (!empty($date)) {
        $date_parts = explode('/', $date);
        if (count($date_parts) == 3 && checkdate($date_parts[1], $date_parts[0], $date_parts[2])) {
            // Valid date format
            $formatted_date = $date_parts[2] . '-' . $date_parts[1] . '-' . $date_parts[0]; // Convert to YYYY-MM-DD for database
        } else {
            $errors[] = "Invalid date format. Please use dd/mm/yyyy";
        }
    }
    
    // Check if user has remaining sessions
    if ($remaining_sessions <= 0) {
        $errors[] = "You have no remaining sessions left";
    }
    
    if (empty($errors)) {
        try {
            // Here you would insert into reservations table
            // For now, we'll just show a success message
            $success_message = "Reservation submitted successfully!";
            
            // You can add this code later when you create the reservations table:
            /*
            $insert_stmt = $pdo->prepare("
                INSERT INTO reservations (user_id, id_number, name, purpose, laboratory, time_in, reservation_date, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
            ");
            $insert_stmt->execute([
                $user_id,
                $_SESSION['id_number'],
                $_SESSION['user_name'],
                $purpose,
                $lab,
                $time_in,
                $formatted_date
            ]);
            */
            
        } catch (PDOException $e) {
            error_log("Reservation error: " . $e->getMessage());
            $error_message = "Failed to submit reservation. Please try again.";
        }
    } else {
        $error_message = implode(", ", $errors);
    }
}

// Get list of laboratories (you can move this to database later)
$laboratories = [
    'Lab 501' => 'Lab 501 - Programming',
    'Lab 502' => 'Lab 502 - Networking',
    'Lab 503' => 'Lab 503 - Multimedia',
    'Lab 504' => 'Lab 504 - Research',
    'Lab 505' => 'Lab 505 - General Purpose'
];

// Get purposes (you can move this to database later)
$purposes = [
    'Programming' => 'Programming',
    'Research' => 'Research',
    'Web Development' => 'Web Development',
    'Multimedia' => 'Multimedia',
    'Networking' => 'Networking',
    'Capstone Project' => 'Capstone Project',
    'Thesis' => 'Thesis',
    'Other' => 'Other'
];
?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/user_navigation.php'; ?>

<!-- Reservation Container -->
<div class="dashboard-container">
    <div class="dashboard-main" style="max-width: 800px; margin: 0 auto;">
        
        <!-- Page Header -->
        <div class="dashboard-header">
            <h1>Lab Reservation</h1>
            <div class="date-badge">
                <i class="far fa-calendar-alt"></i>
                <?php echo date('F j, Y'); ?>
            </div>
        </div>

        <!-- Success/Error Messages -->
        <?php if ($success_message): ?>
            <div class="alert success" style="background: rgba(16,185,129,0.1); color: #6ee7b7; border: 1px solid rgba(16,185,129,0.2); padding: 15px 20px; border-radius: 12px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-check-circle"></i>
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert error" style="background: rgba(239,68,68,0.1); color: #fca5a5; border: 1px solid rgba(239,68,68,0.2); padding: 15px 20px; border-radius: 12px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <!-- Reservation Form Card -->
        <div class="card" style="padding: 30px;">
            <div class="card-header" style="margin-bottom: 25px;">
                <div class="card-title">
                    <i class="fas fa-calendar-check"></i>
                    <h2>Reserve a Laboratory Slot</h2>
                </div>
            </div>

            <form method="POST" action="" style="width: 100%;">
                <!-- ID Number (Read-only) -->
                <div style="margin-bottom: 20px;">
                    <label style="display: block; color: #64748b; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 8px;">
                        <i class="fas fa-id-card" style="margin-right: 5px; color: #60a5fa;"></i>
                        ID Number
                    </label>
                    <input type="text" 
                           value="<?php echo htmlspecialchars($_SESSION['id_number']); ?>" 
                           style="width: 100%; padding: 13px 16px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; color: #94a3b8; font-size: 0.92rem; cursor: not-allowed;"
                           readonly disabled>
                </div>

                <!-- Student Name (Read-only) -->
                <div style="margin-bottom: 20px;">
                    <label style="display: block; color: #64748b; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 8px;">
                        <i class="fas fa-user" style="margin-right: 5px; color: #60a5fa;"></i>
                        Student Name
                    </label>
                    <input type="text" 
                           value="<?php echo htmlspecialchars($_SESSION['user_name']); ?>" 
                           style="width: 100%; padding: 13px 16px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; color: #94a3b8; font-size: 0.92rem; cursor: not-allowed;"
                           readonly disabled>
                </div>

                <!-- Purpose Dropdown -->
                <div style="margin-bottom: 20px;">
                    <label style="display: block; color: #64748b; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 8px;">
                        <i class="fas fa-tasks" style="margin-right: 5px; color: #60a5fa;"></i>
                        Purpose <span style="color: #f87171;">*</span>
                    </label>
                    <select name="purpose" required
                            style="width: 100%; padding: 13px 16px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; color: #f1f5f9; font-size: 0.92rem; transition: all 0.2s ease; appearance: none;"
                            onfocus="this.style.borderColor='rgba(96,165,250,0.45)'; this.style.background='rgba(255,255,255,0.08)';"
                            onblur="this.style.borderColor='rgba(255,255,255,0.08)'; this.style.background='rgba(255,255,255,0.05)';">
                        <option value="" style="background: #1e293b;">Select Purpose</option>
                        <?php foreach ($purposes as $value => $label): ?>
                            <option value="<?php echo $value; ?>" style="background: #1e293b;"><?php echo $label; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Laboratory Dropdown -->
                <div style="margin-bottom: 20px;">
                    <label style="display: block; color: #64748b; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 8px;">
                        <i class="fas fa-flask" style="margin-right: 5px; color: #60a5fa;"></i>
                        Laboratory <span style="color: #f87171;">*</span>
                    </label>
                    <select name="lab" required
                            style="width: 100%; padding: 13px 16px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; color: #f1f5f9; font-size: 0.92rem; transition: all 0.2s ease; appearance: none;"
                            onfocus="this.style.borderColor='rgba(96,165,250,0.45)'; this.style.background='rgba(255,255,255,0.08)';"
                            onblur="this.style.borderColor='rgba(255,255,255,0.08)'; this.style.background='rgba(255,255,255,0.05)';">
                        <option value="" style="background: #1e293b;">Select Laboratory</option>
                        <?php foreach ($laboratories as $value => $label): ?>
                            <option value="<?php echo $value; ?>" style="background: #1e293b;"><?php echo $label; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Time In -->
                <div style="margin-bottom: 20px;">
                    <label style="display: block; color: #64748b; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 8px;">
                        <i class="fas fa-clock" style="margin-right: 5px; color: #60a5fa;"></i>
                        Time In <span style="color: #f87171;">*</span>
                    </label>
                    <input type="time" 
                           name="time_in"
                           value="<?php echo date('H:i'); ?>"
                           style="width: 100%; padding: 13px 16px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; color: #f1f5f9; font-size: 0.92rem; transition: all 0.2s ease;"
                           onfocus="this.style.borderColor='rgba(96,165,250,0.45)'; this.style.background='rgba(255,255,255,0.08)';"
                           onblur="this.style.borderColor='rgba(255,255,255,0.08)'; this.style.background='rgba(255,255,255,0.05)';"
                           required>
                </div>

                <!-- Date (dd/mm/yyyy) -->
                <div style="margin-bottom: 20px;">
                    <label style="display: block; color: #64748b; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 8px;">
                        <i class="fas fa-calendar-alt" style="margin-right: 5px; color: #60a5fa;"></i>
                        Date (dd/mm/yyyy) <span style="color: #f87171;">*</span>
                    </label>
                    <input type="text" 
                           name="date"
                           placeholder="dd/mm/yyyy"
                           value="<?php echo date('d/m/Y'); ?>"
                           style="width: 100%; padding: 13px 16px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; color: #f1f5f9; font-size: 0.92rem; transition: all 0.2s ease;"
                           onfocus="this.style.borderColor='rgba(96,165,250,0.45)'; this.style.background='rgba(255,255,255,0.08)';"
                           onblur="this.style.borderColor='rgba(255,255,255,0.08)'; this.style.background='rgba(255,255,255,0.05)';"
                           pattern="\d{2}/\d{2}/\d{4}"
                           title="Please enter date in dd/mm/yyyy format"
                           required>
                    <small style="color: #475569; font-size: 0.75rem; margin-top: 5px; display: block;">Format: dd/mm/yyyy (e.g., 25/12/2024)</small>
                </div>

                <!-- Remaining Sessions (Read-only) -->
                <div style="margin-bottom: 30px;">
                    <label style="display: block; color: #64748b; font-size: 0.75rem; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 8px;">
                        <i class="fas fa-hourglass-half" style="margin-right: 5px; color: #60a5fa;"></i>
                        Remaining Sessions
                    </label>
                    <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 13px 16px; display: flex; align-items: center; gap: 10px;">
                        <span style="color: <?php echo $remaining_sessions > 10 ? '#6ee7b7' : ($remaining_sessions > 5 ? '#fcd34d' : '#fca5a5'); ?>; font-size: 1.2rem; font-weight: 700;">
                            <?php echo $remaining_sessions; ?>
                        </span>
                        <span style="color: #94a3b8; font-size: 0.9rem;">sessions left</span>
                    </div>
                </div>

                <!-- Submit Button - Centered -->
                <div style="display: flex; gap: 15px; justify-content: center; align-items: center; margin-top: 20px;">
                    <button type="submit" 
                            name="reserve"
                            <?php echo $remaining_sessions <= 0 ? 'disabled' : ''; ?>
                            style="background: <?php echo $remaining_sessions <= 0 ? 'rgba(100,116,139,0.3)' : 'linear-gradient(135deg, #2563eb, #7c3aed)'; ?>; color: <?php echo $remaining_sessions <= 0 ? '#64748b' : 'white'; ?>; border: none; padding: 14px 48px; border-radius: 999px; font-size: 1rem; font-weight: 600; cursor: <?php echo $remaining_sessions <= 0 ? 'not-allowed' : 'pointer'; ?>; display: inline-flex; align-items: center; gap: 8px; box-shadow: <?php echo $remaining_sessions <= 0 ? 'none' : '0 4px 20px rgba(37,99,235,0.4)'; ?>; transition: all 0.25s ease;"
                            onmouseover="if(<?php echo $remaining_sessions <= 0 ? 'false' : 'true'; ?>) { this.style.transform='translateY(-2px)'; this.style.boxShadow='0 12px 36px rgba(37,99,235,0.55)'; }"
                            onmouseout="if(<?php echo $remaining_sessions <= 0 ? 'false' : 'true'; ?>) { this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 20px rgba(37,99,235,0.4)'; }">
                        <i class="fas fa-calendar-check"></i>
                        Reserve
                    </button>
                    
                    <a href="dashboard.php" 
                       style="background: rgba(255,255,255,0.07); color: #94a3b8; text-decoration: none; padding: 14px 32px; border-radius: 999px; font-size: 1rem; font-weight: 500; display: inline-flex; align-items: center; gap: 8px; border: 1px solid rgba(255,255,255,0.08); transition: all 0.25s ease;"
                       onmouseover="this.style.background='rgba(255,255,255,0.12)'; this.style.color='#f1f5f9';"
                       onmouseout="this.style.background='rgba(255,255,255,0.07)'; this.style.color='#94a3b8';">
                        <i class="fas fa-times"></i>
                        Cancel
                    </a>
                </div>
            </form>
        </div>

        <!-- Info Card -->
        <div class="card" style="margin-top: 20px; padding: 20px; background: rgba(37,99,235,0.05);">
            <div style="display: flex; align-items: flex-start; gap: 15px;">
                <i class="fas fa-info-circle" style="color: #60a5fa; font-size: 1.5rem;"></i>
                <div>
                    <h4 style="color: #f1f5f9; margin-bottom: 5px;">Reservation Guidelines</h4>
                    <ul style="color: #94a3b8; font-size: 0.85rem; margin-left: 20px; line-height: 1.6;">
                        <li>Each reservation consumes 1 session from your remaining sessions</li>
                        <li>Please arrive on time for your reservation</li>
                        <li>Cancellations must be made at least 1 hour before the scheduled time</li>
                        <li>Maximum of 2 reservations per day</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add this script for date validation -->
<script>
document.querySelector('input[name="date"]').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length >= 2) {
        value = value.substring(0,2) + '/' + value.substring(2);
    }
    if (value.length >= 5) {
        value = value.substring(0,5) + '/' + value.substring(5,9);
    }
    e.target.value = value.substring(0,10);
});
</script>

<?php include '../includes/footer.php'; ?>