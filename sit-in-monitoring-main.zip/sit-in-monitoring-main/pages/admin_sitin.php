<?php
session_start();

if(!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: login.php?error=" . urlencode("Unauthorized access"));
    exit();
}

require_once __DIR__ . '/../config/database.php';

$pageTitle = "Sit-in - CCS Sit-in System";
$basePath  = "../";

// Handle Sit In form submission
$success_message = '';
$error_message   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sitin_submit'])) {
    $id_number = trim($_POST['id_number'] ?? '');
    $purpose   = trim($_POST['purpose']   ?? '');
    $lab       = trim($_POST['lab']       ?? '');

    if (empty($id_number) || empty($purpose) || empty($lab)) {
        $error_message = "All fields are required.";
    } else {
        // Find the student
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id_number = ? LIMIT 1");
        $stmt->execute([$id_number]);
        $student = $stmt->fetch();

        if (!$student) {
            $error_message = "No student found with ID number: " . htmlspecialchars($id_number);
        } else {
            // TODO: Insert into sit_in table when you create it
            // For now just show success
            $success_message = "Sit-in recorded for " . htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) . "!";
        }
    }
}

// Fetch student by ID for the modal (AJAX or form prefill)
$prefill_student = null;
if (isset($_GET['find_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id_number = ? LIMIT 1");
    $stmt->execute([trim($_GET['find_id'])]);
    $prefill_student = $stmt->fetch();
}

$laboratories = ['524', '526', '528', '530', 'Lab 517'];
$purposes     = ['C Programming','Java','PHP','ASP.Net','C#','Python','Research','Thesis','Capstone','Other'];
?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/admin_navigation.php'; ?>

<style>
:root {
    --primary:           #2563eb;
    --primary-light:     #3b82f6;
    --accent:            #0ea5e9;
    --text-primary:      #f1f5f9;
    --text-secondary:    #cbd5e1;
    --text-muted:        #94a3b8;
    --text-label:        #7dd3fc;
    --border-light:      rgba(255,255,255,0.10);
    --border-hover:      rgba(14,165,233,0.40);
    --shadow-md:         0 8px 32px rgba(0,0,0,0.50);
    --shadow-lg:         0 20px 60px rgba(0,0,0,0.60);
    --radius-lg:         28px;
    --radius-md:         16px;
    --radius-sm:         10px;
    --transition:        all 0.25s ease;
    --card-bg:           rgba(10,18,40,0.82);
    --card-bg-hover:     rgba(14,24,52,0.90);
    --card-border:       rgba(255,255,255,0.10);
    --card-border-hover: rgba(14,165,233,0.45);
    --success:           #10b981;
    --danger:            #ef4444;
}

.sitin-page-container {
    min-height: 100vh;
    padding: 90px 24px 48px;
    position: relative;
}

.sitin-page-container::before {
    content: '';
    position: fixed;
    inset: 0;
    background:
        radial-gradient(ellipse at 5%   0%,  rgba(37,99,235,0.35)  0%, transparent 45%),
        radial-gradient(ellipse at 95% 100%, rgba(14,165,233,0.25) 0%, transparent 45%),
        radial-gradient(ellipse at 75%  15%, rgba(124,58,237,0.18) 0%, transparent 38%),
        radial-gradient(ellipse at 25%  85%, rgba(16,185,129,0.12) 0%, transparent 38%);
    pointer-events: none;
    z-index: -1;
}

.sitin-main {
    max-width: 1200px;
    margin: 0 auto;
    position: relative;
    z-index: 2;
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 28px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--border-light);
}

.page-header h1 {
    font-size: 1.75rem;
    font-weight: 700;
    color: var(--text-primary);
    letter-spacing: -0.02em;
}

.date-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 18px;
    background: rgba(10,18,40,0.70);
    border: 1px solid var(--border-light);
    border-radius: 999px;
    color: var(--text-secondary);
    font-size: 0.875rem;
    backdrop-filter: blur(12px);
}
.date-badge i { color: var(--accent); }

/* Alert */
.alert {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 14px 20px;
    border-radius: var(--radius-sm);
    margin-bottom: 1.5rem;
    font-size: 0.9rem;
    font-weight: 500;
}
.alert-success {
    background: rgba(16,185,129,0.12);
    border: 1px solid rgba(16,185,129,0.25);
    color: #6ee7b7;
}
.alert-error {
    background: rgba(239,68,68,0.12);
    border: 1px solid rgba(239,68,68,0.25);
    color: #fca5a5;
}

/* Card */
.dash-card {
    background: var(--card-bg);
    border: 1px solid var(--card-border);
    border-radius: var(--radius-md);
    backdrop-filter: blur(24px);
    overflow: hidden;
    transition: var(--transition);
    margin-bottom: 1.5rem;
}

.dash-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem 1.25rem;
    background: rgba(37,99,235,0.20);
    border-bottom: 1px solid var(--border-light);
}

.dash-card-header-left {
    display: flex;
    align-items: center;
    gap: 0.6rem;
}

.dash-card-header i { color: var(--accent); }
.dash-card-header h3 {
    color: var(--text-primary);
    font-size: 1rem;
    font-weight: 600;
    margin: 0;
}

.dash-card-body { padding: 1.25rem; }

/* Sit In Button */
.btn-sitin-open {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.5rem 1.25rem;
    background: linear-gradient(135deg, var(--primary), #1d4ed8);
    color: #fff;
    border: none;
    border-radius: var(--radius-sm);
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    font-family: inherit;
}

.btn-sitin-open:hover {
    background: linear-gradient(135deg, var(--primary-light), var(--primary));
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(37,99,235,0.4);
}

/* Table */
.results-table-wrapper { overflow-x: auto; }

.results-table {
    width: 100%;
    border-collapse: collapse;
}

.results-table thead tr {
    background: rgba(255,255,255,0.03);
    border-bottom: 1px solid var(--border-light);
}

.results-table th {
    padding: 1rem 1.25rem;
    text-align: left;
    color: var(--text-muted);
    font-weight: 600;
    font-size: 0.75rem;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    white-space: nowrap;
}

.results-table tbody tr {
    border-bottom: 1px solid rgba(255,255,255,0.04);
    transition: var(--transition);
}

.results-table tbody tr:last-child { border-bottom: none; }
.results-table tbody tr:hover { background: rgba(255,255,255,0.04); }

.results-table td {
    padding: 1rem 1.25rem;
    color: var(--text-secondary);
    font-size: 0.9rem;
    vertical-align: middle;
}

.td-name  { color: var(--text-primary) !important; font-weight: 600; }
.td-id    { color: var(--text-label)   !important; font-weight: 600; font-size: 0.85rem; }

.badge {
    display: inline-block;
    padding: 0.2rem 0.7rem;
    border-radius: 999px;
    font-size: 0.75rem;
    font-weight: 600;
}
.badge-active {
    background: rgba(16,185,129,0.12);
    border: 1px solid rgba(16,185,129,0.25);
    color: #6ee7b7;
}
.badge-course {
    background: rgba(37,99,235,0.15);
    border: 1px solid rgba(37,99,235,0.3);
    color: #93c5fd;
}

.empty-state {
    padding: 3rem;
    text-align: center;
}
.empty-state i {
    font-size: 3rem;
    color: var(--text-muted);
    opacity: 0.4;
    margin-bottom: 1rem;
    display: block;
}
.empty-state h3 { color: var(--text-primary); margin-bottom: 0.4rem; }
.empty-state p  { color: var(--text-muted); font-size: 0.875rem; }

/* ── MODAL ───────────────────────────────────────────────────────────────── */
.modal-overlay {
    position: fixed;
    inset: 0;
    background: rgba(8,14,26,0.88);
    backdrop-filter: blur(10px);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.25s ease;
}

.modal-overlay.open {
    opacity: 1;
    pointer-events: all;
}

.modal-box {
    background: #0d1829;
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: var(--radius-lg);
    padding: 0;
    max-width: 520px;
    width: 92%;
    box-shadow: var(--shadow-lg);
    position: relative;
    overflow: hidden;
    transform: translateY(20px);
    transition: transform 0.3s ease;
}

.modal-overlay.open .modal-box {
    transform: translateY(0);
}

.modal-box::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
    background: linear-gradient(90deg, var(--primary), var(--accent), #7c3aed);
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid var(--border-light);
}

.modal-header h2 {
    color: var(--text-primary);
    font-size: 1.15rem;
    font-weight: 700;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.modal-header h2 i { color: var(--accent); }

.modal-close {
    width: 32px;
    height: 32px;
    background: rgba(255,255,255,0.06);
    border: 1px solid var(--border-light);
    border-radius: 8px;
    color: var(--text-muted);
    font-size: 1rem;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: var(--transition);
}

.modal-close:hover {
    background: rgba(239,68,68,0.15);
    border-color: rgba(239,68,68,0.3);
    color: #fca5a5;
}

.modal-body { padding: 1.5rem; }

/* Form fields inside modal */
.form-group { margin-bottom: 1.1rem; }

.form-label {
    display: block;
    color: var(--text-muted);
    font-size: 0.75rem;
    font-weight: 600;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    margin-bottom: 0.4rem;
}

.form-label i { color: var(--accent); margin-right: 4px; }

.form-control {
    width: 100%;
    padding: 0.7rem 1rem;
    background: rgba(255,255,255,0.05);
    border: 1px solid var(--border-light);
    border-radius: var(--radius-sm);
    color: var(--text-primary);
    font-size: 0.9rem;
    font-family: inherit;
    transition: var(--transition);
    box-sizing: border-box;
}

.form-control:focus {
    outline: none;
    border-color: var(--accent);
    background: rgba(255,255,255,0.08);
    box-shadow: 0 0 0 3px rgba(14,165,233,0.15);
}

.form-control::placeholder { color: var(--text-muted); }

.form-control[readonly],
.form-control[disabled] {
    background: rgba(255,255,255,0.02);
    color: var(--text-muted);
    cursor: not-allowed;
    border-color: rgba(255,255,255,0.05);
}

.form-control-sessions {
    color: #6ee7b7 !important;
    font-weight: 700;
    font-size: 1rem !important;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}

.modal-footer {
    display: flex;
    justify-content: flex-end;
    gap: 0.75rem;
    padding: 1.25rem 1.5rem;
    border-top: 1px solid var(--border-light);
}

.btn-close-modal {
    padding: 0.6rem 1.5rem;
    background: rgba(255,255,255,0.06);
    border: 1px solid var(--border-light);
    border-radius: var(--radius-sm);
    color: var(--text-secondary);
    font-size: 0.9rem;
    font-weight: 500;
    cursor: pointer;
    transition: var(--transition);
    font-family: inherit;
}

.btn-close-modal:hover {
    background: rgba(255,255,255,0.10);
    color: var(--text-primary);
}

.btn-sitin-submit {
    padding: 0.6rem 1.75rem;
    background: linear-gradient(135deg, var(--primary), #1d4ed8);
    border: none;
    border-radius: var(--radius-sm);
    color: #fff;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    font-family: inherit;
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
}

.btn-sitin-submit:hover {
    background: linear-gradient(135deg, var(--primary-light), var(--primary));
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(37,99,235,0.4);
}

/* ID lookup row */
.id-lookup-row {
    display: flex;
    gap: 0.5rem;
}

.id-lookup-row .form-control { flex: 1; }

.btn-lookup {
    padding: 0.7rem 1rem;
    background: rgba(14,165,233,0.15);
    border: 1px solid rgba(14,165,233,0.3);
    border-radius: var(--radius-sm);
    color: var(--text-label);
    font-size: 0.85rem;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    font-family: inherit;
    white-space: nowrap;
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
}

.btn-lookup:hover {
    background: rgba(14,165,233,0.25);
    color: #fff;
}
</style>

<?php if ($success_message): ?>
<div class="alert alert-success" style="max-width:1200px;margin:100px auto 0;padding-left:0;padding-right:0;">
    <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
</div>
<?php endif; ?>
<?php if ($error_message): ?>
<div class="alert alert-error" style="max-width:1200px;margin:100px auto 0;">
    <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
</div>
<?php endif; ?>

<div class="sitin-page-container">
    <div class="sitin-main">

        <!-- Page Header -->
        <div class="page-header">
            <h1>Sit-in Management</h1>
            <div class="date-badge">
                <i class="far fa-calendar-alt"></i>
                <?php echo date('F j, Y'); ?>
            </div>
        </div>

        <!-- Current Sit-in Sessions Card -->
        <div class="dash-card">
            <div class="dash-card-header">
                <div class="dash-card-header-left">
                    <i class="fas fa-clock"></i>
                    <h3>Current Sit-in Sessions</h3>
                </div>
                <button class="btn-sitin-open" onclick="openModal()">
                    <i class="fas fa-plus"></i> Sit-in
                </button>
            </div>
            <div class="dash-card-body">
                <div class="results-table-wrapper">
                    <table class="results-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>ID Number</th>
                                <th>Student Name</th>
                                <th>Purpose</th>
                                <th>Laboratory</th>
                                <th>Time In</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Replace with real DB query when sit_in table exists -->
                            <tr>
                                <td colspan="8">
                                    <div class="empty-state">
                                        <i class="fas fa-chair"></i>
                                        <h3>No active sit-in sessions</h3>
                                        <p>Click the <strong>Sit-in</strong> button to start a new session.</p>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- ── SIT-IN MODAL ─────────────────────────────────────────────────────────── -->
<div class="modal-overlay" id="sitinModal">
    <div class="modal-box">
        <div class="modal-header">
            <h2><i class="fas fa-user-clock"></i> Sit-in Form</h2>
            <button class="modal-close" onclick="closeModal()" title="Close">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <form method="POST" action="" id="sitinForm">
            <div class="modal-body">

                <!-- ID Number with lookup -->
                <div class="form-group">
                    <label class="form-label">
                        <i class="fas fa-id-card"></i> ID Number
                    </label>
                    <div class="id-lookup-row">
                        <input type="text"
                               name="id_number"
                               id="id_number"
                               class="form-control"
                               placeholder="Enter student ID number"
                               value="<?php echo htmlspecialchars($prefill_student['id_number'] ?? ''); ?>"
                               required>
                        <button type="button" class="btn-lookup" onclick="lookupStudent()">
                            <i class="fas fa-search"></i> Find
                        </button>
                    </div>
                </div>

                <!-- Student Name (auto-filled) -->
                <div class="form-group">
                    <label class="form-label">
                        <i class="fas fa-user"></i> Student Name
                    </label>
                    <input type="text"
                           id="student_name"
                           class="form-control"
                           placeholder="Auto-filled after ID lookup"
                           value="<?php echo isset($prefill_student) ? htmlspecialchars($prefill_student['first_name'] . ' ' . $prefill_student['last_name']) : ''; ?>"
                           readonly>
                </div>

                <!-- Purpose & Lab in a row -->
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-tasks"></i> Purpose
                        </label>
                        <select name="purpose" id="purpose" class="form-control" required>
                            <option value="" style="background:#0d1829;">Select Purpose</option>
                            <?php foreach ($purposes as $p): ?>
                            <option value="<?php echo $p; ?>" style="background:#0d1829;"><?php echo $p; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-flask"></i> Laboratory
                        </label>
                        <select name="lab" id="lab" class="form-control" required>
                            <option value="" style="background:#0d1829;">Select Lab</option>
                            <?php foreach ($laboratories as $l): ?>
                            <option value="<?php echo $l; ?>" style="background:#0d1829;"><?php echo $l; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- Remaining Sessions (auto-filled) -->
                <div class="form-group">
                    <label class="form-label">
                        <i class="fas fa-hourglass-half"></i> Remaining Sessions
                    </label>
                    <input type="text"
                           id="remaining_sessions"
                           class="form-control form-control-sessions"
                           placeholder="Auto-filled after ID lookup"
                           value=""
                           readonly>
                </div>

            </div>

            <div class="modal-footer">
                <button type="button" class="btn-close-modal" onclick="closeModal()">
                    <i class="fas fa-times"></i> Close
                </button>
                <button type="submit" name="sitin_submit" class="btn-sitin-submit">
                    <i class="fas fa-sign-in-alt"></i> Sit In
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('sitinModal').classList.add('open');
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    document.getElementById('sitinModal').classList.remove('open');
    document.body.style.overflow = '';
}

// Close on backdrop click
document.getElementById('sitinModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});

// Close on Escape
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeModal();
});

// AJAX lookup student by ID
function lookupStudent() {
    const id = document.getElementById('id_number').value.trim();
    if (!id) {
        alert('Please enter an ID number first.');
        return;
    }

    const btn = document.querySelector('.btn-lookup');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Finding...';
    btn.disabled = true;

    fetch(`../process/lookup_student.php?id_number=${encodeURIComponent(id)}`)
        .then(r => r.json())
        .then(data => {
            btn.innerHTML = '<i class="fas fa-search"></i> Find';
            btn.disabled  = false;

            if (data.found) {
                document.getElementById('student_name').value       = data.name;
                document.getElementById('remaining_sessions').value = data.sessions;
                document.getElementById('student_name').style.color = '#6ee7b7';
            } else {
                document.getElementById('student_name').value       = 'Student not found';
                document.getElementById('remaining_sessions').value = '';
                document.getElementById('student_name').style.color = '#fca5a5';
            }
        })
        .catch(() => {
            btn.innerHTML = '<i class="fas fa-search"></i> Find';
            btn.disabled  = false;
        });
}

// Allow Enter key to trigger lookup
document.getElementById('id_number').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        lookupStudent();
    }
});

<?php if ($error_message || $success_message): ?>
// Auto-open modal if there was a form submission
openModal();
<?php endif; ?>
</script>

<?php include '../includes/footer.php'; ?>