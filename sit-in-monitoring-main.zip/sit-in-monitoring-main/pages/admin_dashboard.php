<?php
session_start();

if(!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: login.php?error=" . urlencode("Unauthorized access"));
    exit();
}

// ── DB connection + live stats ─────────────────────────────────────────────
require_once __DIR__ . '/../config/database.php';

$stmt = $pdo->query("SELECT COUNT(*) FROM users");
$total_students = $stmt->fetchColumn();

$pageTitle = "Admin Dashboard - CCS Sit-in System";
$basePath  = "../";
?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/admin_navigation.php'; ?>

<style>
:root {
    --primary:           #2563eb;
    --primary-light:     #3b82f6;
    --primary-soft:      rgba(37, 99, 235, 0.18);
    --accent:            #0ea5e9;
    --background:        #080e1a;
    --text-primary:      #f1f5f9;
    --text-secondary:    #cbd5e1;
    --text-muted:        #94a3b8;
    --text-label:        #7dd3fc;
    --border-light:      rgba(255, 255, 255, 0.10);
    --border-hover:      rgba(14, 165, 233, 0.40);
    --shadow-md:         0 8px 32px rgba(0, 0, 0, 0.50);
    --shadow-lg:         0 20px 60px rgba(0, 0, 0, 0.60);
    --radius-lg:         28px;
    --radius-md:         16px;
    --radius-sm:         10px;
    --transition:        all 0.25s ease;
    --success:           #10b981;
    --warning:           #f59e0b;
    --danger:            #ef4444;
    --card-bg:           rgba(10, 18, 40, 0.82);
    --card-bg-hover:     rgba(14, 24, 52, 0.90);
    --card-border:       rgba(255, 255, 255, 0.10);
    --card-border-hover: rgba(14, 165, 233, 0.45);
}

.admin-dashboard-container {
    min-height: 100vh;
    padding: 90px 24px 48px;
    position: relative;
    background: transparent;
}

.admin-dashboard-container::before {
    content: '';
    position: fixed;
    inset: 0;
    background:
        radial-gradient(ellipse at 5%   0%,   rgba(37, 99, 235, 0.35) 0%, transparent 45%),
        radial-gradient(ellipse at 95% 100%,  rgba(14, 165, 233, 0.25) 0%, transparent 45%),
        radial-gradient(ellipse at 75%  15%,  rgba(124, 58, 237, 0.18) 0%, transparent 38%),
        radial-gradient(ellipse at 25%  85%,  rgba(16, 185, 129, 0.12) 0%, transparent 38%);
    pointer-events: none;
    z-index: -1;
}

.admin-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 28px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--border-light);
    max-width: 1400px;
    margin-left: auto;
    margin-right: auto;
}

.admin-header h1 {
    font-size: 1.75rem;
    font-weight: 700;
    color: var(--text-primary);
    letter-spacing: -0.02em;
}

.date-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 18px;
    background: rgba(10, 18, 40, 0.70);
    border: 1px solid var(--border-light);
    border-radius: 999px;
    color: var(--text-secondary);
    font-size: 0.875rem;
    font-weight: 500;
    backdrop-filter: blur(12px);
    transition: var(--transition);
}
.date-badge i { color: var(--accent); }
.date-badge:hover {
    background: rgba(14, 24, 52, 0.90);
    border-color: var(--border-hover);
    color: var(--text-primary);
    transform: translateY(-2px);
}

.admin-main {
    max-width: 1400px;
    margin: 0 auto;
    position: relative;
    z-index: 2;
}

.dashboard-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1.5rem;
}

.dash-card {
    background: var(--card-bg);
    border: 1px solid var(--card-border);
    border-radius: var(--radius-md);
    backdrop-filter: blur(24px);
    -webkit-backdrop-filter: blur(24px);
    overflow: hidden;
    transition: var(--transition);
}

.dash-card:hover {
    background: var(--card-bg-hover);
    border-color: var(--card-border-hover);
    transform: translateY(-3px);
    box-shadow: var(--shadow-md);
}

.dash-card-header {
    display: flex;
    align-items: center;
    gap: 0.6rem;
    padding: 1rem 1.25rem;
    background: rgba(37, 99, 235, 0.20);
    border-bottom: 1px solid var(--border-light);
}

.dash-card-header i {
    color: var(--accent);
    font-size: 1rem;
}

.dash-card-header h3 {
    color: var(--text-primary);
    font-size: 1rem;
    font-weight: 600;
    margin: 0;
}

.dash-card-body {
    padding: 1.25rem;
}

.stat-row {
    display: flex;
    flex-direction: column;
    gap: 0.6rem;
    margin-bottom: 1.25rem;
}

.stat-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--text-secondary);
    font-size: 0.95rem;
}

.stat-item strong {
    color: #ffffff;
    font-weight: 700;
    font-size: 1rem;
}

.chart-wrapper {
    position: relative;
    height: 280px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.chart-legend {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem 1rem;
    margin-top: 0.75rem;
}

.legend-item {
    display: flex;
    align-items: center;
    gap: 0.4rem;
    font-size: 0.8rem;
    color: var(--text-secondary);
}

.legend-dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    flex-shrink: 0;
}

.announcement-label {
    color: var(--text-muted);
    font-size: 0.8rem;
    margin-bottom: 0.4rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.announcement-textarea {
    width: 100%;
    min-height: 80px;
    background: rgba(255,255,255,0.04);
    border: 1px solid var(--border-light);
    border-radius: var(--radius-sm);
    color: var(--text-primary);
    font-size: 0.9rem;
    padding: 0.75rem;
    resize: vertical;
    transition: var(--transition);
    font-family: inherit;
    box-sizing: border-box;
}

.announcement-textarea:focus {
    outline: none;
    border-color: var(--accent);
    background: rgba(255,255,255,0.07);
}

.btn-submit {
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    margin-top: 0.75rem;
    padding: 0.5rem 1.4rem;
    background: linear-gradient(135deg, var(--primary), #1d4ed8);
    color: #fff;
    border: none;
    border-radius: var(--radius-sm);
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
    font-family: inherit;
}

.btn-submit:hover {
    background: linear-gradient(135deg, var(--primary-light), var(--primary));
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(37,99,235,0.4);
}

.posted-title {
    color: var(--text-primary);
    font-size: 1.1rem;
    font-weight: 700;
    margin: 1.25rem 0 0.75rem;
    padding-top: 1rem;
    border-top: 1px solid var(--border-light);
}

.announcement-post {
    padding: 0.75rem 0;
    border-bottom: 1px solid var(--border-light);
}

.announcement-post:last-child { border-bottom: none; }

.post-meta {
    color: var(--text-label);
    font-size: 0.82rem;
    font-weight: 600;
    margin-bottom: 0.3rem;
}

.post-content {
    color: var(--text-secondary);
    font-size: 0.875rem;
    line-height: 1.5;
}

.modal-overlay {
    position: fixed;
    inset: 0;
    background: rgba(8, 14, 26, 0.90);
    backdrop-filter: blur(10px);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    animation: fadeIn 0.3s ease;
}

.modal-container {
    background: #0d1829;
    border: 1px solid rgba(255,255,255,0.14);
    border-radius: var(--radius-lg);
    padding: 40px 36px;
    max-width: 450px;
    width: 90%;
    text-align: center;
    box-shadow: var(--shadow-lg);
    animation: slideUp 0.35s ease;
    position: relative;
    overflow: hidden;
}

.modal-container::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
    background: linear-gradient(90deg, var(--primary), var(--accent), #7c3aed);
}

.modal-icon {
    width: 80px; height: 80px;
    background: rgba(255,215,0,0.15);
    border: 1px solid rgba(255,215,0,0.3);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 20px;
}
.modal-icon i { font-size: 2.5rem; color: #ffd700; }
.modal-title { color: #fff; font-size: 1.8rem; font-weight: 700; margin-bottom: 10px; }
.modal-message { color: var(--text-secondary); font-size: 1rem; margin-bottom: 24px; }
.modal-user-info {
    background: rgba(255,255,255,0.03);
    border: 1px solid var(--border-light);
    border-radius: var(--radius-sm);
    padding: 16px; margin-bottom: 24px; text-align: left;
}
.modal-info-item {
    display: flex; align-items: center; gap: 12px;
    padding: 8px 0; color: #e2e8f0;
    border-bottom: 1px solid rgba(255,255,255,0.06);
}
.modal-info-item:last-child { border-bottom: none; }
.modal-info-item i { width: 20px; color: var(--accent); }
.modal-btn {
    display: inline-flex; align-items: center; justify-content: center;
    gap: 8px; padding: 12px 32px;
    background: linear-gradient(135deg, var(--primary), #7c3aed);
    color: #fff; border: none; border-radius: 999px;
    font-family: inherit; font-size: 0.95rem; font-weight: 600;
    cursor: pointer; transition: var(--transition); width: 100%;
    box-shadow: 0 4px 16px rgba(37,99,235,0.40);
}
.modal-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(37,99,235,0.55); }

@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes slideUp {
    from { opacity: 0; transform: translateY(24px); }
    to   { opacity: 1; transform: translateY(0); }
}

@media (max-width: 900px) {
    .dashboard-grid { grid-template-columns: 1fr; }
}

@media (max-width: 768px) {
    .admin-dashboard-container { padding: 80px 16px 40px; }
    .admin-header { flex-direction: column; gap: 12px; text-align: center; }
}
</style>

<!-- SUCCESS MODAL -->
<?php if(isset($_GET['success'])): ?>
<div class="modal-overlay" id="successModal">
    <div class="modal-container">
        <div class="modal-icon"><i class="fas fa-crown"></i></div>
        <h2 class="modal-title">Welcome, Admin!</h2>
        <p class="modal-message"><?php echo htmlspecialchars($_GET['success']); ?></p>
        <div class="modal-user-info">
            <div class="modal-info-item">
                <i class="fas fa-id-card"></i>
                <span><?php echo htmlspecialchars($_SESSION['id_number']); ?></span>
            </div>
            <div class="modal-info-item">
                <i class="fas fa-user-shield"></i>
                <span><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
            </div>
            <div class="modal-info-item">
                <i class="fas fa-envelope"></i>
                <span><?php echo htmlspecialchars($_SESSION['user_email']); ?></span>
            </div>
        </div>
        <button class="modal-btn" onclick="closeModal()">
            <i class="fas fa-check"></i> OK, Got It!
        </button>
    </div>
</div>
<script>
function closeModal() {
    document.getElementById('successModal').style.display = 'none';
    const url = new URL(window.location.href);
    url.searchParams.delete('success');
    window.history.replaceState({}, document.title, url.toString());
}
window.onclick = function(e) {
    const modal = document.getElementById('successModal');
    if (e.target === modal) closeModal();
};
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeModal();
});
</script>
<?php endif; ?>

<!-- ADMIN DASHBOARD -->
<div class="admin-dashboard-container">

    <div class="admin-header">
        <h1>Admin Dashboard</h1>
        <div class="date-badge">
            <i class="far fa-calendar-alt"></i>
            <?php echo date('F j, Y'); ?>
        </div>
    </div>

    <div class="admin-main">
        <div class="dashboard-grid">

            <!-- LEFT: Statistics -->
            <div class="dash-card">
                <div class="dash-card-header">
                    <i class="fas fa-chart-pie"></i>
                    <h3>Statistics</h3>
                </div>
                <div class="dash-card-body">
                    <div class="stat-row">
                        <div class="stat-item">
                            Students Registered: <strong>&nbsp;<?php echo $total_students; ?></strong>
                        </div>
                        <div class="stat-item">
                            Currently Sit-in: <strong>&nbsp;<?php echo 0; ?></strong>
                        </div>
                        <div class="stat-item">
                            Total Sit-in: <strong>&nbsp;<?php echo 0; ?></strong>
                        </div>
                    </div>

                    <!-- Pie Chart -->
                    <div class="chart-wrapper">
                        <canvas id="sitinPieChart"></canvas>
                    </div>
                    <div class="chart-legend" id="chartLegend"></div>
                </div>
            </div>

            <!-- RIGHT: Announcement -->
            <div class="dash-card">
                <div class="dash-card-header">
                    <i class="fas fa-bullhorn"></i>
                    <h3>Announcement</h3>
                </div>
                <div class="dash-card-body">

                    <!-- Post new announcement -->
                    <form method="POST" action="../process/post_announcement.php">
                        <div class="announcement-label">New Announcement</div>
                        <textarea name="announcement"
                                  class="announcement-textarea"
                                  placeholder="Type your announcement here..."></textarea>
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-paper-plane"></i> Submit
                        </button>
                    </form>

                    <!-- Posted announcements -->
                    <div class="posted-title">Posted Announcement</div>

                    <?php
                    $announcements = [
                        ['admin' => 'CCS Admin', 'date' => '2026-Feb-11', 'content' => ''],
                        ['admin' => 'CCS Admin', 'date' => '2024-May-08', 'content' => 'Important Announcement — We are excited to announce the launch of our new website! 🎉 Explore our latest products and services now!'],
                    ];
                    foreach ($announcements as $ann): ?>
                    <div class="announcement-post">
                        <div class="post-meta">
                            <?php echo htmlspecialchars($ann['admin']); ?> | <?php echo htmlspecialchars($ann['date']); ?>
                        </div>
                        <?php if (!empty($ann['content'])): ?>
                        <div class="post-content"><?php echo htmlspecialchars($ann['content']); ?></div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>

                </div>
            </div>

        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const labels  = ['C#', 'C', 'Java', 'ASP.Net', 'PHP'];
const data    = [30, 20, 25, 15, 10];
const colors  = ['#3b82f6', '#ec4899', '#f97316', '#eab308', '#8b5cf6'];

const ctx = document.getElementById('sitinPieChart').getContext('2d');
new Chart(ctx, {
    type: 'pie',
    data: {
        labels: labels,
        datasets: [{
            data: data,
            backgroundColor: colors,
            borderColor: 'rgba(10,18,40,0.8)',
            borderWidth: 2,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: { display: false }
        }
    }
});

const legend = document.getElementById('chartLegend');
labels.forEach((label, i) => {
    legend.innerHTML += `
        <div class="legend-item">
            <div class="legend-dot" style="background:${colors[i]}"></div>
            <span>${label}</span>
        </div>`;
});
</script>

<?php include '../includes/footer.php'; ?>