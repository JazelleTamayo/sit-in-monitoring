<?php
session_start();

// Auth guard - redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?error=" . urlencode("Please login first"));
    exit();
}

// Redirect admin to admin dashboard
if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true) {
    header("Location: admin_dashboard.php");
    exit();
}

$pageTitle = "Sit-in History - CCS Sit-in System";
$extraCSS = "dashboard";
$basePath = "../";

// Get current user info
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];
$id_number = $_SESSION['id_number'];
?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/user_navigation.php'; ?>

<!-- History Container -->
<div class="dashboard-container">
    <div class="dashboard-main" style="max-width: 1200px; margin: 0 auto;">
        
        <!-- Page Header -->
        <div class="dashboard-header">
            <h1>Sit-in History</h1>
            <div class="date-badge">
                <i class="far fa-calendar-alt"></i>
                <?php echo date('F j, Y'); ?>
            </div>
        </div>

        <!-- History Card -->
        <div class="card" style="padding: 25px;">
            
            <!-- Controls: Entries per page and Search -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; flex-wrap: wrap; gap: 15px;">
                
                <!-- Entries per page -->
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span style="color: #94a3b8; font-size: 0.9rem;">Show</span>
                    <select id="entriesSelect" onchange="changeEntries(this.value)" 
                            style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); color: #f1f5f9; padding: 8px 12px; border-radius: 10px; font-size: 0.9rem; cursor: pointer;">
                        <option value="10" selected style="background: #1e293b;">10</option>
                        <option value="25" style="background: #1e293b;">25</option>
                        <option value="50" style="background: #1e293b;">50</option>
                        <option value="100" style="background: #1e293b;">100</option>
                    </select>
                    <span style="color: #94a3b8; font-size: 0.9rem;">entries</span>
                </div>
                
                <!-- Search bar with button -->
                <div style="display: flex; gap: 10px;">
                    <form method="GET" action="" style="display: flex; gap: 10px;">
                        <input type="text" 
                               name="search" 
                               placeholder="Search by purpose or laboratory..." 
                               style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); color: #f1f5f9; padding: 10px 15px; border-radius: 10px; width: 250px; font-size: 0.9rem;">
                        <button type="submit" 
                                style="background: linear-gradient(135deg, #2563eb, #7c3aed); color: white; border: none; padding: 10px 20px; border-radius: 10px; font-size: 0.9rem; font-weight: 500; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                            <i class="fas fa-search"></i> Search
                        </button>
                    </form>
                </div>
            </div>

            <!-- History Table -->
            <div style="overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: rgba(255,255,255,0.03); border-bottom: 1px solid rgba(255,255,255,0.08);">
                            <th style="padding: 15px; text-align: left; color: #94a3b8; font-weight: 600; font-size: 0.8rem; letter-spacing: 0.05em; text-transform: uppercase;">ID Number</th>
                            <th style="padding: 15px; text-align: left; color: #94a3b8; font-weight: 600; font-size: 0.8rem; letter-spacing: 0.05em; text-transform: uppercase;">Name</th>
                            <th style="padding: 15px; text-align: left; color: #94a3b8; font-weight: 600; font-size: 0.8rem; letter-spacing: 0.05em; text-transform: uppercase;">Sit Purpose</th>
                            <th style="padding: 15px; text-align: left; color: #94a3b8; font-weight: 600; font-size: 0.8rem; letter-spacing: 0.05em; text-transform: uppercase;">Laboratory</th>
                            <th style="padding: 15px; text-align: left; color: #94a3b8; font-weight: 600; font-size: 0.8rem; letter-spacing: 0.05em; text-transform: uppercase;">Login</th>
                            <th style="padding: 15px; text-align: left; color: #94a3b8; font-weight: 600; font-size: 0.8rem; letter-spacing: 0.05em; text-transform: uppercase;">Logout</th>
                            <th style="padding: 15px; text-align: left; color: #94a3b8; font-weight: 600; font-size: 0.8rem; letter-spacing: 0.05em; text-transform: uppercase;">Date</th>
                            <th style="padding: 15px; text-align: center; color: #94a3b8; font-weight: 600; font-size: 0.8rem; letter-spacing: 0.05em; text-transform: uppercase;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- No data available message -->
                        <tr>
                            <td colspan="8" style="padding: 50px; text-align: center; color: #94a3b8;">
                                <i class="fas fa-database" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.5; display: block;"></i>
                                <h3 style="color: #f1f5f9; margin-bottom: 5px;">NO data available</h3>
                                <p style="font-size: 0.9rem;">You haven't had any sit-in sessions yet.</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Table Footer with Showing entries -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 25px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.08); flex-wrap: wrap; gap: 15px;">
                
                <!-- Showing entries text -->
                <div style="color: #94a3b8; font-size: 0.9rem;">
                    Showing 0 to 0 of 0 entries
                </div>

                <!-- Pagination Navigation (hidden since no data) -->
                <div style="display: flex; gap: 5px; align-items: center; opacity: 0.5;">
                    <span style="background: rgba(255,255,255,0.03); color: #475569; padding: 8px 12px; border-radius: 8px; font-size: 0.9rem; cursor: not-allowed;">
                        <i class="fas fa-angle-double-left"></i>
                    </span>
                    <span style="background: rgba(255,255,255,0.03); color: #475569; padding: 8px 16px; border-radius: 8px; font-size: 0.9rem; cursor: not-allowed;">
                        <i class="fas fa-angle-left"></i> Prev
                    </span>
                    <span style="background: linear-gradient(135deg, #2563eb, #7c3aed); color: white; padding: 8px 14px; border-radius: 8px; font-size: 0.9rem;">1</span>
                    <span style="background: rgba(255,255,255,0.03); color: #475569; padding: 8px 16px; border-radius: 8px; font-size: 0.9rem; cursor: not-allowed;">
                        Next <i class="fas fa-angle-right"></i>
                    </span>
                    <span style="background: rgba(255,255,255,0.03); color: #475569; padding: 8px 12px; border-radius: 8px; font-size: 0.9rem; cursor: not-allowed;">
                        <i class="fas fa-angle-double-right"></i>
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript for entries per page -->
<script>
function changeEntries(value) {
    // Just reload with the new entries value
    let url = new URL(window.location.href);
    url.searchParams.set('entries', value);
    url.searchParams.set('page', 1);
    window.location.href = url.toString();
}
</script>

<?php include '../includes/footer.php'; ?>