<!-- Admin Navigation Bar -->
<nav class="navbar admin-navbar">
    <div class="nav-container">
        <div class="logo">
            <i class="fas fa-crown" style="color: #ffd700;"></i>
            <span>CCS <span class="logo-highlight">Admin</span></span>
        </div>
        
        <ul class="nav-menu">
            <li><a href="admin_dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'admin_dashboard.php' ? 'active' : ''; ?>">
                <i class="fas fa-home"></i> Home
            </a></li>

            <li><a href="admin_search.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'admin_search.php' ? 'active' : ''; ?>">
                <i class="fas fa-search"></i> Search
            </a></li>

            <li><a href="admin_students.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'admin_students.php' ? 'active' : ''; ?>">
                <i class="fas fa-users"></i> Students
            </a></li>

            <!-- Sit-in Dropdown -->
            <li class="nav-dropdown">
                <a href="#" class="nav-dropdown-toggle <?php echo in_array(basename($_SERVER['PHP_SELF']), ['admin_sitin.php','admin_sitin_records.php','admin_sitin_reports.php','admin_feedback_reports.php']) ? 'active' : ''; ?>"
                   onclick="toggleDropdown(event, this)">
                    <i class="fas fa-clock"></i> Sit-in <i class="fas fa-chevron-down dropdown-arrow"></i>
                </a>
                <ul class="dropdown-menu" id="sitinDropdown">
                    <li><a href="admin_sitin.php">
                        <i class="fas fa-clock"></i> Sit-in
                    </a></li>
                    <li><a href="admin_sitin_records.php">
                        <i class="fas fa-list-alt"></i> View Sit-in Records
                    </a></li>
                    <li><a href="admin_sitin_reports.php">
                        <i class="fas fa-chart-bar"></i> Sit-in Reports
                    </a></li>
                    <li><a href="admin_feedback_reports.php">
                        <i class="fas fa-comment-alt"></i> Feedback Reports
                    </a></li>
                </ul>
            </li>

            <li><a href="admin_reservation.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'admin_reservation.php' ? 'active' : ''; ?>">
                <i class="fas fa-calendar-check"></i> Reservation
            </a></li>

            <li>
                <a href="logout.php" class="btn-logout-nav">
                    <i class="fas fa-sign-out-alt"></i> Log out
                </a>
            </li>
        </ul>
        
        <div class="menu-toggle" id="menuToggle">
            <i class="fas fa-bars"></i>
        </div>
    </div>
</nav>

<!-- Mobile Menu for Admin -->
<div class="mobile-menu" id="mobileMenu">
    <a href="admin_dashboard.php" class="mobile-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_dashboard.php' ? 'active' : ''; ?>">
        <i class="fas fa-home"></i> Home
    </a>
    <a href="admin_search.php" class="mobile-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_search.php' ? 'active' : ''; ?>">
        <i class="fas fa-search"></i> Search
    </a>
    <a href="admin_students.php" class="mobile-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_students.php' ? 'active' : ''; ?>">
        <i class="fas fa-users"></i> Students
    </a>
    <a href="admin_sitin.php" class="mobile-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_sitin.php' ? 'active' : ''; ?>">
        <i class="fas fa-clock"></i> Sit-in
    </a>
    <a href="admin_sitin_records.php" class="mobile-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_sitin_records.php' ? 'active' : ''; ?>">
        <i class="fas fa-list-alt"></i> View Sit-in Records
    </a>
    <a href="admin_sitin_reports.php" class="mobile-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_sitin_reports.php' ? 'active' : ''; ?>">
        <i class="fas fa-chart-bar"></i> Sit-in Reports
    </a>
    <a href="admin_feedback_reports.php" class="mobile-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_feedback_reports.php' ? 'active' : ''; ?>">
        <i class="fas fa-comment-alt"></i> Feedback Reports
    </a>
    <a href="admin_reservation.php" class="mobile-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_reservation.php' ? 'active' : ''; ?>">
        <i class="fas fa-calendar-check"></i> Reservation
    </a>
    <div class="mobile-divider"></div>
    <a href="logout.php" class="mobile-link logout">
        <i class="fas fa-sign-out-alt"></i> Log out
    </a>
</div>

<style>
.nav-dropdown { position: relative; }

.nav-dropdown-toggle {
    display: flex;
    align-items: center;
    gap: 0.4rem;
    cursor: pointer;
    user-select: none;
}

.dropdown-arrow {
    font-size: 0.65rem;
    margin-left: 2px;
    transition: transform 0.25s ease;
}

.nav-dropdown-toggle.dropdown-open .dropdown-arrow {
    transform: rotate(180deg);
}

/* Hidden by default — JS controls visibility */
.nav-dropdown .dropdown-menu {
    display: none;
    position: absolute;
    top: calc(100% + 12px);
    left: 50%;
    transform: translateX(-50%);
    background: #0d1829;
    border: 1px solid rgba(255,255,255,0.10);
    border-radius: 14px;
    min-width: 210px;
    padding: 8px;
    box-shadow: 0 16px 48px rgba(0,0,0,0.6);
    z-index: 9999;
}

.nav-dropdown .dropdown-menu.open {
    display: block;
    animation: dropdownFade 0.2s ease forwards;
}

@keyframes dropdownFade {
    from { opacity: 0; transform: translateX(-50%) translateY(-6px); }
    to   { opacity: 1; transform: translateX(-50%) translateY(0); }
}

.nav-dropdown .dropdown-menu li { list-style: none; }

.nav-dropdown .dropdown-menu li a {
    display: flex;
    align-items: center;
    gap: 0.6rem;
    padding: 0.65rem 1rem;
    color: #cbd5e1;
    text-decoration: none;
    border-radius: 10px;
    font-size: 0.875rem;
    font-weight: 500;
    transition: all 0.2s ease;
    white-space: nowrap;
}

.nav-dropdown .dropdown-menu li a:hover {
    background: rgba(37,99,235,0.20);
    color: #7dd3fc;
}

.nav-dropdown .dropdown-menu li a i {
    color: #0ea5e9;
    width: 16px;
    font-size: 0.85rem;
}

.nav-dropdown .dropdown-menu li:not(:last-child) {
    border-bottom: 1px solid rgba(255,255,255,0.05);
    margin-bottom: 2px;
    padding-bottom: 2px;
}

.mobile-divider {
    height: 1px;
    background: rgba(255,255,255,0.1);
    margin: 10px 0;
}

.admin-navbar .btn-logout-nav {
    background: linear-gradient(135deg, #dc2626, #b91c1c) !important;
    color: white !important;
    box-shadow: 0 4px 12px rgba(220,38,38,0.3) !important;
    padding: 0.4rem 1.2rem !important;
    border-radius: 30px;
    font-size: 0.9rem !important;
    font-weight: 500 !important;
    transition: all 0.25s ease !important;
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    text-decoration: none;
}

.admin-navbar .btn-logout-nav:hover {
    background: linear-gradient(135deg, #b91c1c, #991b1b) !important;
    transform: translateY(-2px);
    box-shadow: 0 8px 16px rgba(220,38,38,0.4) !important;
}

.admin-navbar .btn-logout-nav i { color: white; font-size: 1rem; }
</style>

<script>
function toggleDropdown(e, el) {
    e.preventDefault();
    e.stopPropagation();

    const menu = el.nextElementSibling;
    const isOpen = menu.classList.contains('open');

    // Close all dropdowns first
    document.querySelectorAll('.dropdown-menu.open').forEach(m => m.classList.remove('open'));
    document.querySelectorAll('.nav-dropdown-toggle.dropdown-open').forEach(t => t.classList.remove('dropdown-open'));

    // Toggle this one
    if (!isOpen) {
        menu.classList.add('open');
        el.classList.add('dropdown-open');
    }
}

// Click outside to close
document.addEventListener('click', function(e) {
    if (!e.target.closest('.nav-dropdown')) {
        document.querySelectorAll('.dropdown-menu.open').forEach(m => m.classList.remove('open'));
        document.querySelectorAll('.nav-dropdown-toggle.dropdown-open').forEach(t => t.classList.remove('dropdown-open'));
    }
});
</script>