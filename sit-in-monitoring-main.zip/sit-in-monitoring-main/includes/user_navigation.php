<!-- User Navigation Bar - for logged-in users ONLY -->
<nav class="navbar">
    <div class="nav-container">
        <div class="logo">
            <i class="fas fa-laptop-code"></i>
            <span>CCS <span class="logo-highlight">Student</span></span>
        </div>
        
        <ul class="nav-menu">
            <li><a href="<?= $basePath ?>pages/dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                <i class="fas fa-home"></i> Home
            </a></li>
            <li><a href="<?= $basePath ?>pages/notifications.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'notifications.php' ? 'active' : ''; ?>">
                <i class="fas fa-bell"></i> Notifications
            </a></li>
            <li><a href="<?= $basePath ?>pages/edit_profile.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'edit_profile.php' ? 'active' : ''; ?>">
                <i class="fas fa-user-edit"></i> Edit Profile
            </a></li>
            <li><a href="<?= $basePath ?>pages/history.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'history.php' ? 'active' : ''; ?>">
                <i class="fas fa-history"></i> History
            </a></li>
            <li><a href="<?= $basePath ?>pages/reservation.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'reservation.php' ? 'active' : ''; ?>">
                <i class="fas fa-calendar-check"></i> Reservation
            </a></li>
            <li><a href="<?= $basePath ?>pages/logout.php" class="btn-logout-nav">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a></li>
        </ul>
        
        <div class="menu-toggle" id="menuToggle">
            <i class="fas fa-bars"></i>
        </div>
    </div>
</nav>

<!-- Mobile Menu -->
<div class="mobile-menu" id="mobileMenu">
    <a href="<?= $basePath ?>pages/dashboard.php" class="mobile-link">Home</a>
    <a href="<?= $basePath ?>pages/notifications.php" class="mobile-link">Notifications</a>
    <a href="<?= $basePath ?>pages/edit_profile.php" class="mobile-link">Edit Profile</a>
    <a href="<?= $basePath ?>pages/history.php" class="mobile-link">History</a>
    <a href="<?= $basePath ?>pages/reservation.php" class="mobile-link">Reservation</a>
    <div class="mobile-divider"></div>
    <a href="<?= $basePath ?>pages/logout.php" class="mobile-link logout">Logout</a>
</div>